# PortafolioDjangoBlogBootstrap

# Clonar un Repositorio

Para clonar un repositorio, ejecuta el siguiente comando en tu terminal:

```
git clone <url-del-repositorio>
```

Asegúrate de reemplazar `<url-del-repositorio>` con la URL del repositorio que deseas clonar.

