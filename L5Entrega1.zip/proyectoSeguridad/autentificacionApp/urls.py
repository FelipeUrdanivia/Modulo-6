# from django.urls import path
# from . import views

# urlpatterns = [
#     path('mi-vista', views.MiVista.as_view(), name='mi_vista'),
#     path('otra-vista/', views.OtraVista.as_view(), name='otra_vista'),
#     path('acceso-denegado/', views.acceso_denegado, name='acceso_denegado'),
#     path('accounts/login/', views.LoginView.as_view(), name='login'), 
# ]
