from django.urls import path
from . import views

urlpatterns = [
    path('', views.add_comment, name='add_comment'),
    path('exito/', views.exito, name='exito'),
    path('view_comments/', views.view_comments, name='view_comments'),
]
