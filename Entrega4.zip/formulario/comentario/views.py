from django.shortcuts import render, redirect
from .models import Comment
from .forms import CommentForm

def exito(request):
    return render(request, 'exito.html')

def add_comment(request):
    if request.method == 'POST':
        form = CommentForm(request.POST)
        if form.is_valid():
            comment = form.save(commit=False)
            comment.save()
            return redirect('exito')
    else:
        form = CommentForm()
    return render(request, 'comment_form.html', {'form': form})

def view_comments(request):
    comentarios = Comment.objects.all()
    return render(request, 'view_comments.html', {'comentarios': comentarios})